namespace operacoes.xunit;

public class UnitTest1
{
    [Fact]
    public void SomarDoisNumeros()
    {
        double num1 = 1;
        double num2 = 1;
        double res = 2;
 
        var resultado = Operacoes.Somar(num1, num2);
    
        Assert.Equal(resultado, res);
    }
